<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "teliolimpia2018";


$conn = new mysqli($servername, $username, $password, $dbname);


if ($conn->connect_error) {
    die("Kapcsolódási hiba: " . $conn->connect_error);
}


$helyszinekResult = $conn->query("SELECT sportagneve, varos, helyszin FROM sportagak");
$helyszinek = $helyszinekResult->fetch_all(MYSQLI_ASSOC);


$helyezesekResult = $conn->query("SELECT * FROM helyezettek ORDER BY orszag");
$helyezesek = $helyezesekResult->fetch_all(MYSQLI_ASSOC);


$eremszerzokResult = $conn->query("SELECT orszag, SUM(arany + ezust + bronz) as ermek_osszesen FROM helyezettek GROUP BY orszag ORDER BY ermek_osszesen DESC");
$eremszerzok = $eremszerzokResult->fetch_all(MYSQLI_ASSOC);


$conn->close();













